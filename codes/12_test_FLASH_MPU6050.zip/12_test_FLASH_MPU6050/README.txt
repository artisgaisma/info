DEVELOPMENT NOTES:
* iespējamas problēmas ar Serial output ( varbūt jāsadala ziņa pa Serial.print)
* varbūt rūpīgak jāizstrādā ieraksta process, ir novēroti gļuki
=====================================================================================================
   Used libraries, datasheets etc:
      https://github.com/Marzogh/SPIMemory 
      https://github.com/kriswiner/MPU6050
=====================================================================================================
   Change Log:
   15.01.2021 - first test
=====================================================================================================
   To-Do:

   NB:
