make clean

make attiny841at184 $*
make attiny841at147 $*
make attiny841at110 $*
make attiny841at921 $*
make attiny841at737 $*
make attiny841at20 $*
make attiny841at16 $*
make attiny841at12 $*
make attiny841at8 $*
make attiny841at8_int $*
make attiny841at1 $*
make attiny841at1_int $*

make attiny841at184ser1 $*
make attiny841at147ser1 $*
make attiny841at110ser1 $*
make attiny841at921ser1 $*
make attiny841at737ser1 $*
make attiny841at20ser1 $*
make attiny841at16ser1 $*
make attiny841at12ser1 $*
make attiny841at8ser1 $*
make attiny841at1ser1 $*
make attiny841at8_intser1 $*
make attiny841at1_intser1 $*

make attiny441at184 $*
make attiny441at147 $*
make attiny441at110 $*
make attiny441at921 $*
make attiny441at737 $*
make attiny441at20 $*
make attiny441at16 $*
make attiny441at12 $*
make attiny441at8 $*
make attiny441at8_int $*
make attiny441at1 $*
make attiny441at1_int $*

make attiny441at184ser1 $*
make attiny441at147ser1 $*
make attiny441at110ser1 $*
make attiny441at921ser1 $*
make attiny441at737ser1 $*
make attiny441at20ser1 $*
make attiny441at16ser1 $*
make attiny441at12ser1 $*
make attiny441at8ser1 $*
make attiny441at1ser1 $*
make attiny441at8_intser1 $*
make attiny441at1_intser1 $*

make attiny87at184 $*
make attiny87at147 $*
make attiny87at110 $*
make attiny87at921 $*
make attiny87at737 $*
make attiny87at20 $*
make attiny87at16 $*
make attiny87at12 $*
make attiny87at8 $*
make attiny87at1 $*

make attiny167at184 $*
make attiny167at147 $*
make attiny167at110 $*
make attiny167at921 $*
make attiny167at737 $*
make attiny167at20 $*
make attiny167at16 $*
make attiny167at12 $*
make attiny167at8 $*
make attiny167at1 $*

make attiny1634at147 $*
make attiny1634at110 $*
make attiny1634at921 $*
make attiny1634at737 $*
make attiny1634at20 $*
make attiny1634at16 $*
make attiny1634at12 $*
make attiny1634at8 $*
make attiny1634at8_int $*
make attiny1634at1 $*
make attiny1634at1_int $*

make attiny1634at147ser1 $*
make attiny1634at110ser1 $*
make attiny1634at921ser1 $*
make attiny1634at737ser1 $*
make attiny1634at20ser1 $*
make attiny1634at16ser1 $*
make attiny1634at12ser1 $*
make attiny1634at8ser1 $*
make attiny1634at8_intser1 $*
make attiny1634at1ser1 $*
make attiny1634at1_intser1 $*


make attiny828at8 $*
make attiny828at12 $*
make attiny828at16 $*
make attiny828at20 $*
make attiny828at8_int $*
make attiny828at1 $*
make attiny828at1_int $*

make attiny88at20 $*
make attiny88at16 $*
make attiny88at12 $*
make attiny88at8 $*
make attiny88at4 $*
make attiny88at1 $*

make attiny48at20 $*
make attiny48at16 $*
make attiny48at12 $*
make attiny48at8 $*
make attiny48at4 $*
make attiny48at1 $*

make attiny85at184 $*
make attiny85at147 $*
make attiny85at110 $*
make attiny85at921 $*
make attiny85at737 $*
make attiny85at20 $*
make attiny85at16 $*
make attiny85at12 $*
make attiny85at8 $*
make attiny85at1 $*

make attiny45at184 $*
make attiny45at147 $*
make attiny45at110 $*
make attiny45at921 $*
make attiny45at737 $*
make attiny45at20 $*
make attiny45at16 $*
make attiny45at12 $*
make attiny45at8 $*
make attiny45at1 $*

make attiny84at184 $*
make attiny84at147 $*
make attiny84at110 $*
make attiny84at921 $*
make attiny84at737 $*
make attiny84at20 $*
make attiny84at16 $*
make attiny84at12 $*
make attiny84at8 $*
make attiny84at1 $*

make attiny44at184 $*
make attiny44at147 $*
make attiny44at110 $*
make attiny44at921 $*
make attiny44at737 $*
make attiny44at20 $*
make attiny44at16 $*
make attiny44at12 $*
make attiny44at8 $*
make attiny44at1 $*

make attiny861at184 $*
make attiny861at147 $*
make attiny861at110 $*
make attiny861at921 $*
make attiny861at737 $*
make attiny861at20 $*
make attiny861at16 $*
make attiny861at12 $*
make attiny861at8 $*
make attiny861at1 $*

make attiny461at184 $*
make attiny461at147 $*
make attiny461at110 $*
make attiny461at921 $*
make attiny461at737 $*
make attiny461at20 $*
make attiny461at16 $*
make attiny461at12 $*
make attiny461at8 $*
make attiny461at1 $*

