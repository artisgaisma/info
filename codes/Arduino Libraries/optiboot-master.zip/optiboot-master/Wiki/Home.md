Welcome to the optiboot wiki!<br>

## Wiki pages: ##

* [InstallingOnChips](https://github.com/Optiboot/optiboot/blob/master/Wiki/InstallingOnChips.md) - loading Optiboot onto chips, using various tools.
* [CompilingOptiboot](https://github.com/Optiboot/optiboot/blob/master/Wiki/CompilingOptiboot.md)
* [CompilingOptiboot_X](https://github.com/Optiboot/optiboot/blob/master/Wiki/CompilingOptiboot_X.md)
* [HowOptibootWorks](https://github.com/Optiboot/optiboot/blob/master/Wiki/HowOptibootWorks.md)
* [AddingOptibootChipsToIde](https://github.com/Optiboot/optiboot/blob/master/Wiki/AddingOptibootChipsToIde.md)
* [GoodQuestions](https://github.com/Optiboot/optiboot/blob/master/Wiki/GoodQuestions.md) - Frequently asked technical questions
* [OtherVersions](https://github.com/Optiboot/optiboot/blob/master/Wiki/OtherVersions.md) - 3rd party optiboot derivatives with interesting features.
* [Virtual-Boot-Partition](https://github.com/Optiboot/optiboot/blob/master/Wiki/Virtual-Boot-Partition.md) - More about the Virtual Boot Partition.
