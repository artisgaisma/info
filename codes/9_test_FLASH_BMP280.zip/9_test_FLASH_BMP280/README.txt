
FEATURES:
--- Altimeter ---------------------------------------------------------------------------------------
* lasa altimetru pēc lietotāja izvēlēta laika intervāla (bez aiztures, neieskaita kļūdas)
* iestata relatīvo nulles līmeni (nolasa 'n' reizes un izvelk vidējo, neieskaita kļūdas)
--- Atmiņa ------------------------------------------------------------------------------------------
* ieraksta datus pēc lietotāja izvēlēta laika intervāla un minimālā augstuma (bez aiztures)
* ieraksta brīdī izvelk vidējo no pēdejiem 'n' augstuma lasījumiem
* izmanto EEPROM priekš ātri updeitojamiem datu parametriem
* izdzēš no FLASH tikai ierakstītos laukus (patērē max maz laika)

IN_PROGRESS:
* no atmiņās var nolasīt datus sākot ar konkrēta laika momentu


=====================================================================================================
   Used libraries, datasheets etc:
      https://github.com/Marzogh/SPIMemory 
      https://github.com/mahfuz195/BMP280-arduino-library ( memory usage - 26%/25% with test code)
      https://github.com/adafruit/Adafruit_BMP280_Library ( memory usage - 39%/25% with test code)
=====================================================================================================
   Change Log:
   04.12.2020 - added EEPROM for ID and packet count tracking, because 
                in FLASH memory it would take 4KB and data update would take 50ms
   05.12.2020 - added altimeter
   06.12.2020 - added base level for height, attempt to stabilise altimeter readouts
   08.12.2020 - cacthed memory overflows and reduced erase time
		improved code (.h/.cpp files) and altimeter reading
=====================================================================================================
   To-Do:
      # does failed altimeter read get's discarded?
   NB:
      ! erasing whole FLASH memory will take at least 20 seconds
      ! every FLASH memory cell can only be written once, for updating cell please erase it first
      ! its not possible to erase only single FLASH memory cell, only whole sector
      ! for faster FLASH memory writing - flash.writeByte(ID_ADD, sessionID, NOERRCHK);