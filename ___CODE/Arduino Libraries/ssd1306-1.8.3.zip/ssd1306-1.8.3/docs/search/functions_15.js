var searchData=
[
  ['y',['y',['../class_nano_sprite.html#a26447909c8d140e4745205de9ef040c0',1,'NanoSprite::y()'],['../class_nano_fixed_sprite.html#aa5b745d1d556b612bdd00f9bf606c224',1,'NanoFixedSprite::y()']]]
];
