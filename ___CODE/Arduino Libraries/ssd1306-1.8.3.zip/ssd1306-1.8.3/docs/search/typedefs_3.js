var searchData=
[
  ['sprite',['SPRITE',['../nano__gfx__types_8h.html#aad213759092996ab07d6972f3b21945a',1,'nano_gfx_types.h']]]
];
