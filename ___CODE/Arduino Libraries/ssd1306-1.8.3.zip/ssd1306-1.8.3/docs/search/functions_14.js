var searchData=
[
  ['x',['x',['../class_nano_sprite.html#aff8153a3baab3bd30912dc3478a956a2',1,'NanoSprite::x()'],['../class_nano_fixed_sprite.html#a7baf71abddc36b00ec1c782866b5be5c',1,'NanoFixedSprite::x()']]]
];
