var searchData=
[
  ['oleds_3a_20initialization_20and_20service_20functions',['OLEDs: initialization and service functions',['../group___l_c_d___i_n_t_e_r_f_a_c_e___a_p_i.html',1,'']]],
  ['offset',['offset',['../class_adafruit_canvas_ops.html#aa3bc52732d31517596321f0efa40bafe',1,'AdafruitCanvasOps::offset()'],['../class_nano_canvas_ops.html#a0ff1def9b165746092c0c21adf420612',1,'NanoCanvasOps::offset()']]],
  ['offsetend',['offsetEnd',['../class_nano_canvas_ops.html#a1bc33d61da017643851937d680aefa36',1,'NanoCanvasOps']]],
  ['oldselection',['oldSelection',['../struct_s_app_menu.html#ad79da4d78c16e3fbbd2e380dc5763275',1,'SAppMenu']]],
  ['oled_5fsh1106_2eh',['oled_sh1106.h',['../oled__sh1106_8h.html',1,'']]],
  ['oled_5fssd1306_2eh',['oled_ssd1306.h',['../oled__ssd1306_8h.html',1,'']]],
  ['oled_5fssd1325_2eh',['oled_ssd1325.h',['../oled__ssd1325_8h.html',1,'']]],
  ['oled_5fssd1331_2eh',['oled_ssd1331.h',['../oled__ssd1331_8h.html',1,'']]],
  ['oled_5fssd1351_2eh',['oled_ssd1351.h',['../oled__ssd1351_8h.html',1,'']]],
  ['oled_5ftemplate_2eh',['oled_template.h',['../oled__template_8h.html',1,'']]],
  ['operator_2b',['operator+',['../struct___nano_point.html#ae43e5976ea297fa19e2c6802979dd907',1,'_NanoPoint::operator+()'],['../struct___nano_rect.html#a5b1bc5b55fca40919a5da5dc3e93fe7f',1,'_NanoRect::operator+()']]],
  ['operator_2b_3d',['operator+=',['../struct___nano_point.html#a49f5c70f11141579ebcfaee7fb83a7a4',1,'_NanoPoint::operator+=()'],['../struct___nano_rect.html#a504c0982e9e76c09c03b632ff5d9da21',1,'_NanoRect::operator+=()']]],
  ['operator_2d',['operator-',['../struct___nano_point.html#a2e032b491bbeaa37bc3a58a19cb8e818',1,'_NanoPoint::operator-()'],['../struct___nano_rect.html#a283c63d0a75d36aa776228470859ae56',1,'_NanoRect::operator-()']]],
  ['operator_2d_3d',['operator-=',['../struct___nano_point.html#a45975195d121d79477d8f81fa0f1c5bb',1,'_NanoPoint']]],
  ['operator_2f',['operator/',['../struct___nano_point.html#ac3ad2d2f96ee8a71bf5563f7c2b53671',1,'_NanoPoint']]],
  ['operator_3c_3c',['operator&lt;&lt;',['../struct___nano_point.html#a874ccdf5d2627f0924aadce3b2088dc2',1,'_NanoPoint::operator&lt;&lt;()'],['../struct___nano_rect.html#a411cca3962f94fe90bbbd6af635fd6a7',1,'_NanoRect::operator&lt;&lt;()']]],
  ['operator_3c_3c_3d',['operator&lt;&lt;=',['../struct___nano_point.html#aade271ab08c395102371413a84bc929b',1,'_NanoPoint']]],
  ['operator_3e_3e',['operator&gt;&gt;',['../struct___nano_point.html#a7ba51dfc529118a17376ed6002df27fb',1,'_NanoPoint::operator&gt;&gt;()'],['../struct___nano_rect.html#aee53859d064772ec8053c276ad6f1eb0',1,'_NanoRect::operator&gt;&gt;()']]],
  ['operator_3e_3e_3d',['operator&gt;&gt;=',['../struct___nano_point.html#a67231d2647bf16f59f4d848467e789ab',1,'_NanoPoint']]]
];
