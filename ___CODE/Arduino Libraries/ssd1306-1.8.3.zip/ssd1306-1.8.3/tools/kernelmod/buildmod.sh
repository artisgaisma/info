#!/bin/sh

rsync -ru ../../src ./ && make
