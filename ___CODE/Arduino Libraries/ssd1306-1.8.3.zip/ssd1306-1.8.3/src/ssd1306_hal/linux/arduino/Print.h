#ifndef _PRINT_H_
#define _PRINT_H_

#include "ssd1306_hal/io.h"
#include "ssd1306_hal/Print_internal.h"

#define __FlashStringHelper char

#endif

