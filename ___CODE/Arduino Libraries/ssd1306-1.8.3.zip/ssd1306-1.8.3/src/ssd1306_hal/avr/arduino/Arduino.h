#ifndef _ARDUINO_H_
#define _ARDUINO_H_

#define ARDUINO_FAKE
#include "ssd1306_hal/avr/io.h"
#include "ssd1306_hal/Print_internal.h"

#ifndef boolean
    typedef uint8_t boolean;
#endif

#endif

