This is a library for RRE Fonts rendering using all typical GFX libraries
Requires "fillRect()" function.

